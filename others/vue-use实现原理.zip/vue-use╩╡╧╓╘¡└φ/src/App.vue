<template>
    <div>
        <h3>this is install button</h3>
        <test></test>
        <h3>welcome !</h3>
    </div>
</template>

<script>
    export default {
        name: "App"
    }
</script>

<style scoped>

</style>

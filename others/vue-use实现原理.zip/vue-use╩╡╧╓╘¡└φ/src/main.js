import install from "./install";
import Vue from 'vue';
import App from './App'
Vue.use(install);

new Vue({
    el : "#app",
    render: h => h(App)
})

import test from './test'
export default {
    install : function (Vue) {
        Vue.component('test', test);
    }
}

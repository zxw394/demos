<template>
    <button style="width: 200px; height: 50px">
        test button
    </button>
</template>

<script>
    export default {
        name: "test"
    }
</script>

<style scoped>

</style>
